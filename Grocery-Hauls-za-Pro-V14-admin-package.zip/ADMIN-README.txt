GROCERY HAULS ZA PRO — V14 ADMIN PACKAGE
=========================================
Build: 2026-10-28 11:58 UTC (v14 scanner-fixed)
Package verified against the live preview in this workspace.

WHAT THIS IS
------------
The complete V14 static build, including the full admin application.
The admin screens share the compiled app shell with the rest of the
site (same _next bundles), so the whole build is included — this is
the smallest unit in which the admin app can run.

ADMIN ROUTES
------------
  /admin           Admin area. Checks the session and redirects to
                   the login screen when no admin session exists.
  /admin/login     Admin sign-in screen ("Admin Login").

VERIFIED BEHAVIOUR (browser-tested from this build)
---------------------------------------------------
- /admin and /admin/login load correctly (HTTP 200, zero console
  errors).
- "Sign in with Google" launches the real Firebase Google OAuth flow
  (Firebase project: groceryhauls-pro-za-app). This is a live
  client-side flow, not a mock.
- The login screen itself states the authorised administrator Google
  account and that visibility of the page never grants access.

REQUIREMENTS FOR ADMIN SIGN-IN TO COMPLETE
------------------------------------------
1. FIREBASE AUTHORIZED DOMAINS
   The domain you serve this build from must be listed in
   Firebase console > Authentication > Settings > Authorized domains.
   - localhost is authorized by default in every Firebase project.
   - Any other domain (preview or production) must be added by the
     project owner, or Firebase blocks sign-in with
     auth/unauthorized-domain.
2. BACKEND FOR ADMIN DATA SCREENS
   This is a static export: it serves every page and all /data/*.json
   files, but it cannot serve the /api/admin/* endpoints
   (login/users) that some admin screens call. Those endpoints are
   Next.js API routes in the GitHub repository source
   (rickmabz25-design/Grocery-Hauls-za-Pro). Run the repo source
   (or the production deployment) for the full admin backend; the
   static package gives you the admin UI and auth entry point.

HOW TO SERVE THIS PACKAGE
-------------------------
Unzip, then from inside the folder run any static server:
    npx serve .
    python3 -m http.server 3000
Or deploy the folder as-is to Cloudflare Pages (_redirects included).

CONTENTS (114 entries: the 113 build files plus this README)
------------------------------------------------------------
  index.html, login.html, admin.html, admin/login.html, 404.html
  _next/          compiled application bundles
  data/           7 JSON files: stores (10 in-store retailers),
                  online-retailers (12), products, promos, categories,
                  locations, whats-new
  brand/, icons/, manifest.webmanifest, sw.js, _redirects,
  version.txt, ADMIN-README.txt (this file)
